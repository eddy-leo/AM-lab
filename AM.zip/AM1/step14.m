%% initiation
clear;
clc;
load Ximage\Ximage.mat;
array=[-2 0 0; -1 0 0; 0 0 0; 1 0 0; 2 0 0]; 
M = 5;  %Number of sensor
Length=30000;
N = length(X_im);  %Number of snapshots
directions=[30,0;35,0;90,0]; %DOA of image siganl
directionsJ=[30,0;35,0];

S=spv(array,directionsJ);
directionD=[90,0];

S_desired=spv(array,directionD);
OP=fpoc(S);
weight=OP*S_desired;
yt=weight'*X_im; 
%% LMS adaptive
Signal_desired = yt;  % Desired Signal
u = 0.000001;   %adaptation gain
w_mls = zeros(M,1);  %initalize weight
%Update weight
for k = 1:N
    y(k) = w_mls'*X_im(:,k);
    e(k) = Signal_desired(k) - y(k);
    w_mls = w_mls + u * e(k)'*X_im(:,k);
end
Z=patternn(array,w_mls); % Gain reponse for an EM signal come form each direction
plot2d3d(Z,[0:180],0,'gain in dB','Pattern using LMS algorithm (90°as desired direction)',1);
yt1=w_mls'*X_im;
yt_recover1=yt1/max(yt)*255;
displayimage(yt_recover1,image_size,2,'The received signal with DOA of 90 degree using LMS adaptive beamformer');
energy=0;
for n=1:M
    energy=sum(abs(X_im(n,:)).^2)+energy;
end
power=energy/N;
Rxx_im=X_im*X_im'/length(X_im(1,:));
lambda=max(eig(Rxx_im));
mu_max=1/lambda;
%% RLS adaptive
mu=rand;
w_rls=zeros(M,1);
P=inv(eye(M));  %image signals are uncorrelate. 

for p=1:N
e=Signal_desired(p)-w_rls'*X_im(:,p);
g=P*X_im(:,p)/(mu+X_im(:,p)'*P*X_im(:,p));
P=P-g*X_im(:,p)'*P;
w_rls=w_rls+g*conj(e);
end
Z=patternn(array,w_rls); % Gain reponse
plot2d3d(Z,[0:180],0,'gain in dB','Pattern Using RLS Algorithm (90° as desired direction)',3);
figure;
yt2=w_rls'*X_im;
yt_recover2=yt2/max(yt2)*255;
displayimage(yt_recover2,image_size,4,'The Received Signal with DOA of 90 Degree Using RLS Adaptive Beamformer');
