function Rmm_smooth=smooth(M,Rmm,S);


% reconstruct convariance matrix
N=5;
P=3;
NumSub_array=N-P+1;
Rmm_smooth =zeros(M, M);
SS=zeros(M,M);
for k=1:NumSub_array
    SS(k,k)=S(2,k);
for k=1:NumSub_array
    Rmm_smooth=Rmm_smooth+SS^(k-1)*Rmm*(SS^(k-1))';

end
Rmm_smooth=Rmm_smooth/NumSub_array;


end