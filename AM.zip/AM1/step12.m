%% Estimations & Reception Problem - Superre solution Techniques
clc;clear;load Xaudio\Xaudio.mat;load Ximage\Ximage.mat;
array=[-2 0 0;-1 0 0;0 0 0;1 0 0;2 0 0];
directions=[30, 0; 35, 0; 90, 0 ];

%% 12.1
Rxx_au= X_au*X_au'/length(X_au(1,:));%X_au' is Conjugate transpose
Sd=spv(array,[90,0]);%the SPV which corresponds to the desired source 90 degree, change the weight
wopt=inv(Rxx_au)*Sd;%optimum Wiener-Hopf solution
Z=patternn(array,wopt);
%plot2d3d(Z, [0:180], 0,'gain in dB','Rau array pattern',1);
yt=wopt'*X_au;
soundsc(real(yt), 11025);%with the2nd antenna, three sources are mixed

%% 12.2
%displayimage(X_im(2,:),image_size, 201,'The received signal at the 2nd antenna');%image at the output of thesecond antenna, three siganls are mixed
Rxx_im= X_im*X_im'/length(X_im(1,:));%practical covariance matrices
Sd=spv(array,[90,0]);%the SPV which corresponds to the desired source 90 degree, change the weight
wopt=inv(Rxx_im)*Sd;%optimum Wiener-Hopf solution
Z=patternn(array,wopt);
%plot2d3d(Z, [0:180], 0,'gain in dB','Rim array pattern',2);
yt=7000*wopt'*X_im;
displayimage(yt,image_size, 202,'The received signal at o/p of W-H beamformer');

%% 12.3
directions=[30,0;35,0;90,0];
S=spv(array, directions);%get Source Position Vector
Rmm=[1 0 0;0 1 0;0 0 1];%three sources are uncorrelated
Pnoise=40;%-40db
sigma2=10^(-Pnoise/10);%-40db=10logN  Pnoise=10^-4
Rxx_theoretical=S*Rmm*S'+sigma2*eye(5,5);%practical covariance matrices
directionsD30=[30,0];
directionsD35=[35,0];
directionsD90=[90,0];

w30=weight(array,directions,directionsD30);
w35=weight(array,directions,directionsD35);
w90=weight(array,directions,directionsD90);


%for Xim
yt30=6*w30'*X_im;
yt35=7*w35'*X_im;
yt90=0.2*w90'*X_im;
displayimage(yt30,image_size, 203,'The received signal at o/p 30^o of superrresolution beamformer');
displayimage(yt35,image_size, 204,'The received signal at o/p 35^o of superrresolution beamformer');
displayimage(yt90,image_size, 205,'The received signal at o/p 90^o of superrresolution beamformer');
Z30=patternn(array,w30);
Z35=patternn(array,w35);
Z90=patternn(array,w90);
plot2d3d(Z30, [0:180], 0,'gain in dB','Array Pattern from 30° in superresolution beamformer',11);
plot2d3d(Z35, [0:180], 0,'gain in dB','Array Pattern from 35° in superresolution beamformer',12);
plot2d3d(Z90, [0:180], 0,'gain in dB','Array Pattern from 90° in superresolution beamformer',13);



