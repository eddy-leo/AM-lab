%% Multipaths - Coherent Sources
clc;clear;
array=[-2 0 0;-1 0 0;0 0 0;1 0 0;2 0 0];
Rmm=[1 1 0;1 1 0;0 0 1];%30°, 35° are fully correlated
directions=[30, 0; 35, 0 ; 90, 0];
sigma2=10^(-4);
S=spv(array, directions);%get Source Position Vector
Rxx_theoretical=S*Rmm*S'+sigma2*eye(5,5);%practical covariance matrices
[EV,D]=eig(Rxx_theoretical);
EVA_correlated=diag(D)';
M=3;
Z=music(array, Rxx_theoretical, M);
plot2d3d(Z,[0:180],0,'dB', 'MuSIC spectrum-correlated',1);

%% spatial Smoothing technique
Rmm_smooth=smooth(M,Rmm,S);
Rxx_correlated=S*Rmm_smooth*S'+sigma2*eye(5,5);
Z=music(array, Rxx_correlated, M);
plot2d3d(Z,[0:180],0,'dB', 'Music spectrum-theoretical-Rxx-correlated after smoothing',2);