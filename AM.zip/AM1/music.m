function Z = music(array, Rxx_theoretical, M)

N = 5;% 阵元个数        
% M信源数目


%%%%构建信号模型%%%%%

% Rxx_theoretical协方差矩阵
% 特征值分解
[EV,D]=eig(Rxx_theoretical);% EV-Eigen vector D-eigen value特征值分解
EVA=diag(D)';% EVA将特征值矩阵对角线提取并转为一行
[EVA,I]=sort(EVA);%将特征值排序 从小到大
EV=fliplr(EV(:,I));% 对应特征矢量排序  fliplr将矩阵进行左右翻转    

% 遍历每个角度，计算空间谱

for iang = 1:181
    SS=spv(array,[iang-1,0]); % SS方向矢量
    En=EV(:,M+1:N);         % 取矩阵的第M+1到N列组成噪声子空间
    Pmusic(iang)=1/(SS'*En*En'*SS);
end
Z=abs(Pmusic);
Z=10*log10(Pmusic);

end

