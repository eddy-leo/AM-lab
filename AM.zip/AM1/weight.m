function w = weight(array,directions,directionsD)

r=size(directions,1);
directionsJ=[];
for i=1:r
    if isequal(directions(i,:),directionsD(:,:))
        
    else directionsJ=[directionsJ;directions(i,:)];
    end
end

SJ=spv(array,directionsJ);
SD=spv(array,directionsD);

OP=fpoc(SJ);
w=OP*SD;
end