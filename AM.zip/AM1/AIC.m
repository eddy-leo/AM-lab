function R_AIC = AIC(Rxx_practical,N,L)
%UNTITLED2 此处提供此函数的摘要
%   此处提供详细说明

[EV,D]=eig(Rxx_practical);
EVA=diag(D)';
EVA=sort(EVA,'descend');
LF=[];
R_AIC=[];
for k=0:N-1
    gm=1;
    am=0;
    for l=k+1:N
        gm=gm*(EVA(l)^(1/(N-k)));
        am=am+EVA(l);
    end
    am=(1/(N-k))*am;
    LF(k+1)=((N-k)*L)*log(gm/am);
    R_AIC(k+1)=-2*LF(k+1)+2*k*(2*N-k);
end


   
end