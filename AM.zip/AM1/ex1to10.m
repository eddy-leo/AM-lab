%% initiation
clc;clear;
array=[-2 0 0;-1 0 0;0 0 0;1 0 0;2 0 0];
directions=[30, 0; 35, 0 ; 90, 0];
pat=patternn(array);
plot2d3d(pat,[0:180],0,'gain in dB','initial pattern',1);%gain for three sources
[pat(30),pat(35),pat(90)]%gain from three singals
S=spv(array, directions);%get Source Position Vector
Rmm=[1 0 0;0 1 0;0 0 1];%three sources are uncorrelated
Pnoise=40;%-40db
Pnoise1=10;%-10db
sigma2=10^(-Pnoise/10);%-40db=10logN  Pnoise=10^-4
Rxx_theoretical=S*Rmm*S'+sigma2*eye(5,5);%practical covariance matrices
[~,gama,~]=svd(Rxx_theoretical);%eigen decomposition eigen-value gama

%% information received
load Xaudio\Xaudio.mat;load Ximage\Ximage.mat;
soundsc(real(X_au(2,:)), 11025);%with the2nd antenna, three sources are mixed
displayimage(X_im(2,:),image_size, 201,'The received signal at the 2nd antenna');%image at the output of thesecond antenna, three siganls are mixed
Rxx_au= X_au*X_au'/length(X_au(1,:));%X_au' is Conjugate transpose
Rxx_im= X_im*X_im'/length(X_im(1,:));%practical covariance matrices
%% detection
directions=[];Rmm=[];sigma2=[];
[EV,D]=eig(Rxx_theoretical);
EVA=diag(gama);
[~,gama_au,~]=svd(Rxx_au);
[~,gama_im,~]=svd(Rxx_im);%eigenvalues
M=3;

%% estimation-conventional approach
Sd=spv(array,[90,0]);%the SPV which corresponds to the desired source 90 degree, change the weight
wopt=inv(Rxx_theoretical)*Sd;%optimum Wiener-Hopf solution
Z=patternn(array,wopt);
plot2d3d(Z, [0:180], 0,'gain in dB','W-H array pattern',2);

%% estimation-Superresolution Approach
Z=music(array, Rxx_theoretical, M);
plot2d3d(Z,[0:180],0,'dB', 'MuSIC spectrum',3);

%% Rim and Rau-Superresolution Approach
Z=music(array, Rxx_im, M);
plot2d3d(Z,[0:180],0,'dB', 'MuSIC spectrum-Rim',4);

Z=music(array, Rxx_au, M);
plot2d3d(Z,[0:180],0,'dB', 'MuSIC spectrum-Rau',5);









