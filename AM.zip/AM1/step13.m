%% initiation
clc;clear;
load Ximage\Ximage.mat;
load Xaudio\Xaudio.mat;


array=[-2 0 0;-1 0 0;0 0 0;1 0 0;2 0 0];
directions=[30, 0; 35, 0; 90, 0 ];
pat=patternn(array);
S=spv(array, directions);%get Source Position Vector
Rmm=[1 0 0;0 1 0;0 0 1];%three sources are uncorrelated
Pnoise=40;%-40db
sigma2=10^(-Pnoise/10);%-40db=10logN  Pnoise=10^-4
Rxx_theoretical=S*Rmm*S'+sigma2*eye(5,5);%practical covariance matrices
%% generate signals
L=250;
x=sqrt(1/2)*(randn(length(array),L)+1i*randn(length(array),L));
[EV,D]=eig(Rxx_theoretical);
xx=EV*sqrt(D)*x;
Rxx_practical=(xx*xx')/length(xx);%practical covariance matrix
N=5;
R_AIC=AIC(Rxx_practical,length(array),length(x));
R_MDL=MDL(Rxx_practical,length(array),length(x));
Rxx_im = X_im*X_im'/length(X_im);
Rxx_au = X_au*X_au'/length(X_au);
%M4 = AIC(Rxx_im,length(array),length(X_im));
%M5 = MDL(Rxx_im,length(array),length(X_im));
M6 = AIC(Rxx_au,length(array),length(X_au));
M7 = MDL(Rxx_au,length(array),length(X_au));
